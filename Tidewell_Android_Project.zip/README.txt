TIDEWELL ANDROID APK PROJECT

This packages the supplied Tidewell HTML app in a simple Android WebView.
It builds a debug APK using GitHub Actions.

BUILD:
1. Create a GitHub repository and upload the CONTENTS of this folder.
2. Open the repository's Actions tab.
3. Select "Build Tidewell APK" and press "Run workflow".
   (A push to the main branch also starts a build.)
4. Open the completed workflow run.
5. Download the "Tidewell-APK" artifact.
6. Extract the artifact ZIP; app-debug.apk is the installable APK.

NOTES:
- Debug-signed APK for direct sharing/testing, not Play Store publishing.
- Each phone stores its own data locally.
- Clearing app data or uninstalling may remove that phone's data.
- This basic wrapper does not implement native notifications.
